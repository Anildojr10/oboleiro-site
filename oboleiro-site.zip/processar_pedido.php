<?php
$conn = new mysqli("localhost", "root", "", "oboleiro");
if ($conn->connect_error) die("Erro de conexão");

$nome = $_POST['cliente_nome'];
$item = $_POST['item'];
$qtd = $_POST['quantidade'];

$stmt = $conn->prepare("INSERT INTO pedidos (cliente_nome, item, quantidade) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $nome, $item, $qtd);
$stmt->execute();

echo "<h2>Pedido recebido com sucesso!</h2>";
echo "<p><a href='menu.php'>Fazer novo pedido</a> | <a href='historico.php'>Ver histórico</a></p>";
?>