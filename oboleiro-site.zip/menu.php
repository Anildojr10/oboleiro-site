<?php
echo "<h1>Cardápio de Delícias</h1>";
echo "<form method='POST' action='processar_pedido.php'>
  Nome: <input type='text' name='cliente_nome' required><br>
  Item:
  <select name='item'>
    <option>Bolo de Chocolate</option>
    <option>Torta de Limão</option>
    <option>Esfirra de Carne</option>
  </select><br>
  Quantidade: <input type='number' name='quantidade' value='1'><br>
  <input type='submit' value='Fazer Pedido'>
</form>";
?>