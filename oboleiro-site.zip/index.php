<?php
echo "<h1>Bem-vindo ao site da O Boleiro Bolos!</h1>";
echo "<p><a href='menu.php'>Veja nosso cardápio</a></p>";
?>